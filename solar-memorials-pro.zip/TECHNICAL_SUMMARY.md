# Resumo Técnico - Solar Memorials

## Visão Geral

Plataforma web completa em Flask para geração de memoriais descritivos fotovoltaicos profissionais, com autenticação, dashboard, editor dinâmico e exportação em DOCX.

## Stack Tecnológico

### Backend
- **Framework**: Flask 3.0
- **Autenticação**: Flask-Login
- **Banco de Dados**: SQLite com Python sqlite3
- **Segurança**: Werkzeug (password hashing)
- **Documentos**: python-docx + docxtpl (templates Jinja)

### Frontend
- **HTML5**: Templates Jinja2
- **CSS3**: Dark theme profissional com variáveis CSS
- **JavaScript**: Vanilla JS com classes (sem jQuery)
- **Máscaras**: Implementadas em JavaScript puro

## Arquitetura

### Estrutura de Pastas
```
solar-memorials/
├── app.py                    # Aplicação principal (Flask)
├── config.py                 # Configurações globais
├── docx_generator.py         # Gerador de documentos DOCX
├── database/
│   ├── connection.py         # Gerenciador de conexões
│   ├── init_db.py           # Inicialização do banco
│   └── schema.sql           # Schema SQL
├── templates/
│   ├── login.html           # Autenticação
│   ├── registro.html        # Registro de usuários
│   ├── dashboard.html       # Dashboard com métricas
│   ├── editor.html          # Editor de memorial
│   └── modelo_memorial_v2.docx # Template DOCX
├── static/
│   ├── css/style.css        # Estilos CSS
│   └── js/main.js           # JavaScript interativo
└── uploads/                 # Documentos gerados
```

## Componentes Principais

### 1. Autenticação (app.py)
- **Rotas**: `/login`, `/registro`, `/logout`
- **Proteção**: `@login_required` decorator
- **Segurança**: Hash de senha com Werkzeug
- **Sessão**: Flask-Login com remember me

### 2. Database (database/)
- **Conexão**: Context manager com sqlite3
- **Tabelas**: usuarios, projetos
- **Índices**: usuario_id, status para performance
- **Relacionamento**: Chave estrangeira usuario_id

### 3. Dashboard (templates/dashboard.html)
- **Métricas**: 4 cards com KPIs
- **Tabela**: Projetos recentes com status
- **Sidebar**: Navegação e projetos recentes
- **Responsivo**: Grid adaptável

### 4. Editor de Memorial (templates/editor.html)
- **Formulário**: Dinâmico com seções condicionais
- **Tipos**: Instalação Nova, Ampliação, Grid Zero, Art. 73-A
- **Equipamentos**: Adição/remoção dinâmica
- **Cálculos**: Totais automáticos
- **Demo**: Preenchimento com dados de exemplo

### 5. Gerador DOCX (docx_generator.py)
- **Template**: Jinja2 com placeholders
- **Suporte**: Todos os tipos de projeto
- **Loops**: Para múltiplos equipamentos
- **Fallback**: Geração do zero se template não existir

## Fluxo de Dados

### Criação de Projeto
```
Usuário preenche formulário
    ↓
JavaScript valida dados
    ↓
POST /api/projeto/salvar
    ↓
app.py processa e salva no banco
    ↓
Retorna JSON com sucesso
    ↓
Redireciona para dashboard
```

### Geração de DOCX
```
Usuário clica "Gerar DOCX"
    ↓
POST /api/projeto/{id}/gerar-docx
    ↓
docx_generator.py carrega dados
    ↓
Renderiza template com Jinja
    ↓
Salva em uploads/
    ↓
Retorna link para download
```

## Banco de Dados

### Tabela: usuarios
```sql
id INTEGER PRIMARY KEY
email TEXT UNIQUE NOT NULL
nome TEXT NOT NULL
senha_hash TEXT NOT NULL
data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
```

### Tabela: projetos
```sql
id INTEGER PRIMARY KEY
usuario_id INTEGER FOREIGN KEY
nome_cliente, cpf_cnpj, uc, endereco, cidade, uf, cep, concessionaria
data_projeto DATE
tipo_projeto TEXT (Instalação Nova, Ampliação, Grid Zero, Art. 73-A)
modulos_existentes INTEGER
inversores_existentes TEXT
controlador, transdutor_tc, chave_seccionadora TEXT
media_consumo, fator_carga, fator_ajuste REAL
modulos_novos, inversores_novos TEXT (JSON)
potencia_kwp, geracao_kwh_mes, reducao_percentual, area_arranjos REAL
quantidade_modulos INTEGER
status TEXT (Rascunho, Concluído, Aprovado)
data_criacao, data_atualizacao TIMESTAMP
```

## API Endpoints

### Autenticação
- `POST /login` - Login de usuário
- `POST /registro` - Registro de novo usuário
- `GET /logout` - Logout

### Dashboard
- `GET /` - Redireciona para dashboard
- `GET /dashboard` - Dashboard principal

### Projetos
- `GET /projeto/novo` - Formulário novo projeto
- `GET /projeto/<id>` - Editar projeto
- `POST /api/projeto/salvar` - Salvar/atualizar projeto
- `POST /api/projeto/<id>/gerar-docx` - Gerar DOCX
- `GET /downloads/<filename>` - Download de arquivo
- `POST /projeto/<id>/deletar` - Deletar projeto

## Segurança

### Implementado
- Hash de senha com Werkzeug
- Proteção de rotas com login_required
- Session management com Flask-Login
- FOREIGN KEY constraints no banco

### Recomendado para Produção
- HTTPS/SSL
- CSRF protection com Flask-WTF
- Rate limiting
- Validação de entrada mais rigorosa
- Logging de ações
- Backup automático do banco

## Performance

### Otimizações
- Índices no banco de dados
- Context manager para conexões
- Lazy loading de projetos
- Cache de usuários com Flask-Login

### Escalabilidade
- Banco SQLite adequado para até ~100k registros
- Para maior volume, migrar para PostgreSQL
- Implementar cache com Redis
- Usar CDN para arquivos estáticos

## Desenvolvimento

### Adicionar Novo Campo
1. Adicionar coluna em `database/schema.sql`
2. Atualizar formulário em `templates/editor.html`
3. Atualizar `app.py` para processar o campo
4. Atualizar template DOCX se necessário

### Customizar Template DOCX
1. Abrir `templates/modelo_memorial_v2.docx` no Word
2. Adicionar/remover campos conforme necessário
3. Usar `{{ campo }}` para placeholders Jinja
4. Usar `{% if condicao %}...{% endif %}` para lógica
5. Usar `{% for item in lista %}...{% endfor %}` para loops

### Adicionar Novo Tipo de Projeto
1. Adicionar opção em radio buttons (editor.html)
2. Adicionar seção dinâmica com `data-section`
3. Adicionar campos no formulário
4. Atualizar `app.py` para processar
5. Atualizar template DOCX com `{% if eh_novo_tipo %}`

## Testes

### Teste Manual
1. Registrar novo usuário
2. Criar projeto com cada tipo
3. Adicionar múltiplos equipamentos
4. Usar "Preencher Demo"
5. Gerar DOCX e verificar conteúdo

### Teste Automático (Implementar)
```python
import unittest
from app import app

class TestApp(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
    
    def test_login(self):
        response = self.app.get('/login')
        assert response.status_code == 200
```

## Deployment

### Local
```bash
python app.py
```

### Produção (Gunicorn + Nginx)
```bash
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Docker (Opcional)
```dockerfile
FROM python:3.11
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "app.py"]
```

## Monitoramento

### Logs
- Verificar console do Flask
- Implementar logging em arquivo
- Monitorar erros de banco de dados

### Métricas
- Número de usuários
- Projetos criados por período
- Tempo de geração de DOCX
- Erros de autenticação

## Manutenção

### Backup
```bash
cp solar_memorials.db solar_memorials.db.backup
```

### Limpeza
```bash
rm -rf uploads/*.docx  # Limpar documentos antigos
```

### Atualização
1. Backup do banco
2. Atualizar código
3. Instalar novas dependências
4. Testar localmente
5. Deploy em produção

---

**Última atualização**: Jan 05, 2026
**Versão**: 1.0.0
**Status**: Pronto para produção
